import { Client } from 'ssh2';

const conn = new Client();

conn.on('ready', () => {
  conn.exec('echo "Sistemas" | sudo -S id', (err, stream) => {
    if (err) throw err;
    stream.on('close', (code) => {
      console.log('Código de salida sudo:', code);
      conn.end();
    })
    .on('data', (d) => process.stdout.write(d))
    .stderr.on('data', (d) => process.stderr.write(d));
  });
}).connect({
  host: '10.0.0.10',
  port: 22,
  username: 'admin-irg',
  password: 'Sistemas'
});
