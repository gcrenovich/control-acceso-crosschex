import { Client } from 'ssh2';

const conn = new Client();

console.log('Intentando conectar por SSH a 10.0.0.10 con admin-irg...');

conn.on('ready', () => {
  console.log('✅ ¡Conexión SSH exitosa!');
  conn.exec('uname -a && whoami', (err, stream) => {
    if (err) {
      console.error('Error al ejecutar comando:', err);
      conn.end();
      return;
    }
    stream.on('close', (code, signal) => {
      console.log(`Comando finalizado con código: ${code}`);
      conn.end();
    }).on('data', (data) => {
      console.log('Salida: ' + data.toString().trim());
    }).stderr.on('data', (data) => {
      console.error('Error: ' + data.toString().trim());
    });
  });
}).on('error', (err) => {
  console.error('❌ Error de conexión SSH:', err.message);
}).connect({
  host: '10.0.0.10',
  port: 22,
  username: 'admin-irg',
  password: 'Sistemas',
  readyTimeout: 15000
});
